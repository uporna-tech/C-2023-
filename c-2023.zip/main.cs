/******************************************************************************

                            Online C# Compiler.
                Code, Compile, Run and Debug C# program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

using System;
class PasswordGenerator {
  static void Main(string[] args) {
      
   //Letters and numbers
   string big = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   string small = big.ToLower ();
   string digits = "0123456789";
   string specialCharacters = "!@#$%&*()_/";
   
   
   //Getting password configuration
   Console.WriteLine("How many capital letters do you want ?");
   int bigNumber = int.Parse(Console.ReadLine());
   Console.WriteLine("How many digits letters do you want?");
   int digitsNumber= int.Parse(Console.ReadLine());
   Console.WriteLine("How many special characters do you want?");
   int specialCharactersNumber = int.Parse(Console.ReadLine());
  
   
   
   //
   /*multiple
   line
   comments
   */
   //Creating a random value object
   Random randomObject = new Random ();
   
   //Creating a valuable for the password
   string password = "";
   
   
   //Generating specific parts of the password
   //This is for capital letters
   for (int i = 0; i < bigNumber; i++)
   {
       char character = big[randomObject.Next(big.Length)];
       password = password.Insert(randomObject.Next(password.Length +1), character.ToString());
   }
   
   //This is for digits
   for(int i = 0; i < specialCharactersNumber; i++)
   {
       char character = specialCharacters[randomObject.Next(digits.Length)];
       password = password.Insert(randomObject.Next(password.Length +1), character.ToString());
   }
   Console.WriteLine("Your new generated password is: " + password);
   Console.ReadKey();
   
  }
}
